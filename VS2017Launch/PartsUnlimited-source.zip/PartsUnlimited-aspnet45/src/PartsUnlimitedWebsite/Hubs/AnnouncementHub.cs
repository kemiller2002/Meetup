﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;

namespace PartsUnlimited.Hubs
{
    [HubName("Announcement")]
    public class AnnouncementHub : Hub
    {
       
    }
}