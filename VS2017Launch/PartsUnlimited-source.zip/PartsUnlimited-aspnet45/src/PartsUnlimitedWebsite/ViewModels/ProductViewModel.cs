using PartsUnlimited.Models;

namespace PartsUnlimited.ViewModels
{
    public class ProductViewModel
    {
        public Product Product { get; set; }
        public bool ShowRecommendations { get; set; }
    }
}